public class ThrowException extends Exception{
    ThrowException(String message){
        super(message);
    }
}
