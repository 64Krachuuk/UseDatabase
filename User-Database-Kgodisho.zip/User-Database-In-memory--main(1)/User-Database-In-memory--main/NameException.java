public class NameException extends Exception{
	NameException(String message){
		super(message);
	}
}
