import java.util.*;

public class MultiArray{
	public static void main(String args[]){
	
	int multiArray[][] = new int[100][30];
	
	int i = 0;
	while(i < multiArray.length){
		int j = 0;
		while(j < multiArray[i].length){	
			multiArray[i][j] = (int)(Math.random()*60);
			j++;
		}
		i++;
	}
	  System.out.print("\n\n Odd numbers and numbers divisible by 8:\n\n");
	  int k = 0;
	  while(k < multiArray.length){	
		if((k==20 )|| (k==40) ||( k==60) || (k==80 )|| (k==100)){System.out.print("\n\n");}
			int j=0;
			while(j < multiArray[k].length){
				switch(multiArray[k][j]%2){
					case 0 :
					System.out.print(multiArray[k][j] + " ");
					break;
					}
				switch(multiArray[k][j]%11){
					case 0 :
					System.out.print(multiArray[k][j] + " ");
					break;
				}	
				j++;
			}
			k++;
			System.out.print("\n\n");
		}
	}
}
