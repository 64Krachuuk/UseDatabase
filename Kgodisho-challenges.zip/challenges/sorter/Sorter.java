import java.util.*;

public class Sorter{
	public static void main(String args[]){
	
	int arraySort[] = new int[50];
	
	//re-initializing the array
		for(int i=0; i<arraySort.length; i++){
			arraySort[i]=(int)(Math.random()* 60);
		}
		int i=0;
		//printing the array contents
		System.out.println("Unsorted array");
		for(int x:arraySort ){
			System.out.print(x + " ");
			i++;
			if(i==30){System.out.println(" ");}
		}
		System.out.println(" ");
		System.out.println("Before Element 20 : " + arraySort[20] + " " + 
							"Element 21 : " + arraySort[21]);
		
		arraySort[20] += 70;
		arraySort[21] += 61;
		
		System.out.println(" ");
		System.out.println("After Element 20 : " + arraySort[20] + " " + 
						"Element 21 : " + arraySort[21]);
    
    int size = arraySort.length;

    // call quicksort() on array data
    quickSort(arraySort, 0, size - 1);

    System.out.println("Sorted Array in Ascending Order ");
    System.out.println(Arrays.toString(arraySort));
	}

	
		
    

  // method to find the partition position
  public static int partition(int array[], int low, int high) {
    
    // choose the rightmost element as pivot
    int pivot = array[high];
    
    // pointer for greater element
    int i = (low - 1);

    // traverse through all elements
    // compare each element with pivot
    for (int j = low; j < high; j++) {
      if (array[j] <= pivot) {

        // if element smaller than pivot is found
        // swap it with the greater element pointed by i
        i++;

        // swapping element at i with element at j
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }

    }

    // swapt the pivot element with the greater element specified by i
    int temp = array[i + 1];
    array[i + 1] = array[high];
    array[high] = temp;

    // return the position from where partition is done
    return (i + 1);
  }

  static void quickSort(int array[], int low, int high) {
    if (low < high) {

      // find pivot element such that
      // elements smaller than pivot are on the left
      // elements greater than pivot are on the right
      int pi = partition(array, low, high);
      
      // recursive call on the left of pivot
      quickSort(array, low, pi - 1);

      // recursive call on the right of pivot
      quickSort(array, pi + 1, high);
    }
  }
}

	
	
	
	
