import java.util.*;

public class ArrayTest{
	public static void main(String args[]){
	
	int arrayTest[] = new int[50];
	
	System.out.println("\n\nArray contents before adding one:");
	int i=0;
	while(i < arrayTest.length){
		arrayTest[i] = (int)(Math.random()* 60);
		System.out.print(arrayTest[i] + " , ");
	i++;
	}
	System.out.println("\n\nAfter adding");
	
	int j = 0;
	while(j < arrayTest.length){
		arrayTest[j] = arrayTest[j] + 1;
		System.out.print(arrayTest[j]+ " , " );
		j++;
	}
	System.out.print("\n\n Even numbers and numbers divisible by 11\n");
	int x=0;
		while(x < arrayTest.length){ 
			switch(x%2){
				case 0:
				   System.out.print(x + " ");
				   break;
				default:
					System.out.print( " ");
				   break;
			}
	
			switch(x%11){
				case 0:
				System.out.print(x + " ");
				break;
			}
        x++;
		}
	}
}	
		